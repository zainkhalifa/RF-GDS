function [ogelm] = GDS_reset_gelm(igelm,info)
% this fuction will reset the layer and dtype of an element to a new value.
% values are stored in  info.layer and info.dtype
    ogelm = gds_element('boundary','xy',cell2mat(xy(igelm)),'layer',info.layer,'dtype',info.dtype);
end
