function [ogelm] = GDS_shrink_gelm(igelm,d,units)
% this function will trim the gelm from all sides by the vales d = [dx dy] 

% push points inward    
    XY = cell2mat(xy(igelm));

    len1 = floor(length(XY(:,1))/2);
    len2 = length(XY(:,1)) - len1 +1;   
    [SXY,I] = sortrows(XY,2);
    
    SXY(1:len1,:)   = SXY(1:len1,:)     + [0 d(2)].*ones(len1,2);
    SXY(len1:end,:) = SXY(len1:end,:)   - [0 d(2)].*ones(len2,2);
    XY(I,:) = SXY;
 
    [SXY,I] = sortrows(XY,1);
    
    SXY(1:len1,:)   = SXY(1:len1,:)     + [d(1) 0].*ones(len1,2);
    SXY(len1:end,:) = SXY(len1:end,:)   - [d(1) 0].*ones(len2,2);
    XY(I,:) = SXY;
    XYinner = {XY};
% push points outward  
    XY = cell2mat(xy(igelm));

    len1 = floor(length(XY(:,1))/2);
    len2 = length(XY(:,1)) - len1 +1;   
    [SXY,I] = sortrows(XY,2);
    
    SXY(1:len1,:)   = SXY(1:len1,:)     - [0 d(2)].*ones(len1,2);
    SXY(len1:end,:) = SXY(len1:end,:)   + [0 d(2)].*ones(len2,2);
    XY(I,:) = SXY;
 
    [SXY,I] = sortrows(XY,1);
    
    SXY(1:len1,:)   = SXY(1:len1,:)     - [d(1) 0].*ones(len1,2);
    SXY(len1:end,:) = SXY(len1:end,:)   + [d(1) 0].*ones(len2,2);
    XY(I,:) = SXY;
    XYouter = {XY};

    [pc,hf] = poly_boolmex(XYinner,XYouter,'and',units);
    if ~isempty(pc)
        if length(pc(:))>1
            for idx = 1:length(pc(:))
                PC = cell2mat(pc(idx));
                len(idx) = length(PC(:,1));
            end
            [Y,I] = max(len);
            % choose the one with the highest number of elements hoping it is
            % the right one 
            pc = pc(I);        
        end

        XY = cell2mat(pc);
        XY(end+1,:) = XY(1,:);
        % remove consecutive duplicates
        XY(diff(XY(:,1))==0 & diff(XY(:,2))==0,:) = [];

        ogelm = gds_element('boundary','xy',XY,'layer',layer(igelm));
    else
        ogelm = igelm;
    end
end
