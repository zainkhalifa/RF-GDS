function [ogelm] = GDS_shift_gelm(igelm,shift)
    fprintf("\nRunning GDS_shift_gelm...");

%     L = layer(igelm);
    el_size = size(cell2mat(xy(igelm)));
    XY = cell2mat(xy(igelm)) + shift.*ones(el_size);
%     ogelm = gds_element('boundary','xy',XY,'layer',L);
    ogelm = gds_element('boundary','xy',XY);
    
    fprintf("DONE!\n")
end
