function [ogstr] = GDS_shift_gstr(igstr,shift)
    fprintf("\nRunning GDS_shift_gstr...");
% create gds structure with the same name as the input structure    
    ogstr = gds_structure(get(igstr,'sname'));
    
    for idx = 1:length(igstr(:))
    % get the layers of all elements in the input structure     
        L = layer(igstr(idx));
        el_size = size(cell2mat(xy(igstr(idx))));
        XY = cell2mat(xy(igstr(idx))) + shift.*ones(el_size);
        ogstr(1+end) = gds_element('boundary','xy',XY,'layer',L);
    end
    fprintf("DONE!")
end
