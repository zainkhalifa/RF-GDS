function [ogstr] = GDS_diff(gelm,igstr,layer,units)
    fprintf("\nRunning GDS_AND...\n");
	% All elements must be in the positive plane beacuse this function uses
	% poly_boolmex! GDS_AND will run GDS_shift
    t = cputime;

    box_elm = bbox(gelm);
    box_str = bbox(igstr);
    S_gelm = GDS_shift_gelm(gelm,-box_elm(1:2));    
    S_gstr = GDS_shift_gstr(igstr,-box_str(1:2));    
    
    ogstr = gds_structure('anded_gstr');
    for e_idx = 1:length(S_gstr(:))
        [pc_and, hf] =  poly_boolmex(xy(S_gelm), xy(S_gstr(e_idx)), 'diff', units);
        if ~isempty(pc_and)
            XY = cell2mat(pc_and(1));
            XY(end+1,:) = XY(1,:);
            % remove consecutive duplicates
            XY(diff(XY(:,1))==0 & diff(XY(:,2))==0,:) = [];
            ogstr(1+end) = gds_element('boundary','xy',XY,'layer',layer);
%             fprintf("GDS_AND: Elapsed time = %0.2f s\n",(cputime-t));
        end
    end
    
    ogstr = GDS_shift_gstr(ogstr,box_str(1:2));
    
    fprintf("DONE!\n");
end
