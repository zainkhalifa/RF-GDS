function GDS_plot_gstr(gstr,L_sel,str)
% Plot all elements in a GDSII structure and select certain layer to display, 
% str is the plotting option like '-' or '.' 
    if numel(gstr)==0
        fprintf("ZAIN: GDS_plot_gstr: no elmenets in gstr\n")
        return;
    end
    for idx = 1:numel(gstr)       % loop for all elements
        data{idx} = xy(gstr(idx));
    end    
    if L_sel ~= 0
        for idx = 1:numel(gstr)       % loop for all elements
            L(idx) = layer(gstr(idx));
        end
	    if ~ismember(L_sel,L)
            error("ZAIN: Layer selection does not exist in input gds_strcutre")
            return;
        end
        Ldata = data(find(L==L_sel));
    else
        Ldata = data;
    end

    hold on
    for idx = 1:length(Ldata)
        XY = cell2mat(Ldata{idx});
        plot(XY(:,1),XY(:,2),str)
    end
    hold off
    axis equal
end

