function [ogstr]    = GDS_Combine_gstr(igstr,units)
% This is an outdated function to be replaced with GDS_Merge
% This function combine all elements in each layer. You might need to run
% the function more than once becase of a mistake in the GDS libaray!
    fprintf("\nRunning CombineGDS_str...\n");
    for idx = 1:length(igstr(:))
        L(idx) = layer(igstr(idx));
    end
    t=cputime;
    % initiate the output gds_strcut
    ogstr = gds_structure(get(igstr,'sname'));

    % start combining by performing or operation for each layer
    % indepenedantly 
   
    for L_idx = 1:max(L)
        clear LSt
        LSt = gds_structure(get(igstr,'sname'));
        % LSt is a gstr contains only one layer
        Lidx = find(L==L_idx);
        for idx = 1:length(Lidx)
            LSt(idx) = igstr(Lidx(idx));
        end

        % make sure that each element in LSt has only one boundary
        for i=1:length(LSt)
            A = LSt(i);
            if length(A)~=1
                error('ZAIN: reparse LSt so each element in LSt has only one boundary');
            end
        end,clear A


        while(~isempty(LSt(:)))
             fprintf("CombineGDS_str ... ")
             if length(LSt(:)) == 1
                ogstr(1+end) = LSt(1);
                LSt(1) = [];
             else
                % build the connection matrix
                C = logical(zeros(1,length(LSt(:))));
                for idx = 2:length(LSt(:))
                   [xyo, hf] = poly_boolmex(xy(LSt(1)), xy(LSt(idx)), 'or', units);
                   C(idx) = length(xyo(:))==1 | (length(xyo(:))==2 & any(hf));
                end
                if ~any(C)  % no connections, isolated
                    ogstr(1+end) = LSt(1);
                    LSt(1) = [];
                else        % connect the elements
                    C_idx = find(C);
                    for idx = 1:length(C_idx)
                        LSt(1) = Connect_gelm(LSt(1),LSt(C_idx(idx)),units);
                    end
                    LSt(C_idx)=[];
                end
             end
                fprintf("Precessing time = %0.2f s\n",cputime-t)         
        end
    end
    fprintf("DONE!\n");beep;
end

