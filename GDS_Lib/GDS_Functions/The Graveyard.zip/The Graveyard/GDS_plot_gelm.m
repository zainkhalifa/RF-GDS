function GDS_plot_gelm(gelm,str)
    if length(gelm)~=1
        error("ZAIN: Number of elements must be only one")
        return
    end
    if isempty(xy(gelm))
        error("ZAIN: glem is empty")
        return        
    end
    XY = cell2mat(xy(gelm));
    plot(XY(:,1),XY(:,2),str)
    axis equal
end

