function [glib]     = GDS_Export(location,name,istr,uunit,dbunit)
% Export the GDS data to a file named 'name'.
% istr is a gds_structure with all the elements
% istr = rename(istr, name);

if exist(strcat(strcat(location,name,'.gds')),'file')==2
    delete(strcat(location,name,'.gds'));
end

% create library
glib = gds_library(strcat(location,name,'.gds'), 'uunit',uunit, 'dbunit',dbunit, istr);
write_gds_library(glib, strcat(location,name,'.gds'),'unique',0);
S = load ('handel');
sound(S.y,S.Fs)
end

