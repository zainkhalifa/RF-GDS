function [ogstr] = GDS_reset_gstr(igstr,info)
% this fuction will reset the layer and dtype of every elements in the gstr
% to a new values. 
ogstr = {};
    if ~iscell(igstr)
        igstr = {igstr};
    end
    for s_idx = 1:length(igstr(:))
        gstr = igstr{s_idx};
        for e_idx = 1:length(gstr(:))
            gstr(e_idx) = gds_element('boundary','xy',cell2mat(xy(gstr(e_idx))),'layer',info.layer,'dtype',info.dtype);
        end
        ogstr{s_idx} = gstr;
    end

        
    
end







