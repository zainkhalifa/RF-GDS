function [gstr] = GDS_Mosaic_gelm(gelm,d_edge,d,RC)
% function GDS_Mosaic_gelm(gelm,[dx_edge dy_edge],[dx dy],[rows cols])
% gelm is the input gelm that you want to mosaic
% d_edge is the edges seperation or space 
% d is the distance between each tile 
% RC are the rows and cols
    fprintf("\nRunning GDS_Mosaic_gelm...");

    L = layer(gelm);
    XY = gelm(1);
    % centering XY around (0.0)
    XY_dxy = abs([max(XY(:,1))-min(XY(:,1)) max(XY(:,2))-min(XY(:,2))]./2);

    gstr = gds_structure('mosaic');
    rows = RC(1); cols = RC(2);
    d = d + 2*XY_dxy;
    d_edge = d_edge + XY_dxy;
    dx = d(1); dy = d(2);
    dx_edge = d_edge(1); dy_edge = d_edge(2);

    for r_idx = 1:rows
        for c_idx = 1:cols
            shift = [dx_edge+(c_idx-1)*dx dy_edge+(r_idx-1)*dy].*ones(length(XY(:,1)),2);
            gstr(1+end) = gds_element('boundary','xy',XY + shift  ,'layer',L);
        end
    end
    fprintf("DONE!\n");
end
