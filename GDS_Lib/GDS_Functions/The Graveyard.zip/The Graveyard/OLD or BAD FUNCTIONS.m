% Created By Zainulabideen Khalifa , November, 2019
% To work with this file you need to do few thnigs:
% 1) install mex compiler by running the file "mingw.mlpkginstall" or
% google it for other methods if you dont have that file. 
% 2) copy the library to any fixed folder prefereably store it in 
% "C:\Program Files\MATLAB\R2017b\toolbox\gds2-toolbox"
% 3) set path in matlab to include all subfolders in your location of the
% toolbox. you can do that from HOME --> Set Path.
% 4) compile the library by running "makemex.m". you need to do this only
% once. 


%%
% --------------------------------Functions--------------------------------
function plotGDS_str(gstr,L_sel,str)
    for idx = 1:numel(gstr)       % loop for all elements
        data{idx} = xy(gstr(idx));
        L(idx) = layer(gstr(idx));
    end
    if ~ismember(L_sel,L)
        error("ZAIN: Layer selection does not exist in input gds_strcutre")
        return;
    end
    Ldata = data(find(L==L_sel));
   
    hold on
    for idx = 1:length(Ldata)
        XY = cell2mat(Ldata{idx});
        plot(XY(:,1),XY(:,2),str)
    end
    hold off
    axis equal
end
function plotGDS_elm(gelm,str)
    if length(gelm)~=1
        error("ZAIN: Number of elements must be only one")
        return
    end
    if isempty(xy(gelm))
        error("ZAIN: glem is empty")
        return        
    end
    XY = cell2mat(xy(gelm));
    plot(XY(:,1),XY(:,2),str)
    axis equal
end
function plot_GDS(data,str)
    hold on
    for idx = 1:length(data)
        XY = cell2mat(data{idx});
        plot(XY(:,1),XY(:,2),str)
    end
    hold off
    axis equal
end

function [ogstr]    = Discretize_gstr(igstr,minGrid,units)
% This function will discritize a set of points given in Xi and Yi so that
% they are all lies on the grid given minGrid value. The input is a
% gds_structure with all elements. the function will maintian the layer
% information
    fprintf("\nRunning Discretize_gstr...\n");
    % initiate the output gds_strcut
    ogstr = gds_structure(get(igstr,'sname'));
    
    % loop for each element in igstr
    for idx = 1:numel(igstr)
        t = cputime;fprintf("Elm%0.0f:",idx)
        %--------------Start Discritize of one element-----------
        L    = layer(igstr(idx));
        clear XY Xi Yi
        XY = cell2mat(xy(igstr(idx)));
        Xi(:) = XY(:,1)*units;
        Yi(:) = XY(:,2)*units;

        if length(Xi)<2 | length(Yi)<2
            error("ZAIN: Discretize function requires at least two points")
            return
        end
        % opt is used to speed up the processing by choosing the simpliest
        % reference variable
        opt = sum(abs(diff(Yi))) < sum(abs(diff(Xi)));
        if opt
            temp = Xi;Xi = Yi;Yi = temp;
        end
        X = [];
        Y = [];
        for n=1:length(Xi)-1
            [x,y] =  Discritize_2P(Xi(n:n+1),Yi(n:n+1),minGrid);
            X = [X(1:end) x];
            Y = [Y(1:end) y];
        end
        % Precaution if the end point does not coincide on the first
        if X(end) ~= X(1) | Y(end) ~= Y(1)
           X = [X(1:end) X(1)];
           Y = [Y(1:end) Y(1)];
        end
        if opt
            temp = X;X = Y;Y = temp;
        end
        Ddata = [X;Y]'./units;
        % remove consecutive duplicates
        Ddata(diff(Ddata(:,1))==0 & diff(Ddata(:,2))==0,:) = []; 
    	%--------------End of Discritize of one element----------- 
        ogstr(idx) = gds_element('boundary', 'xy',Ddata,'layer',L);
        T(idx) = (cputime-t);
        fprintf("Discretize: Elapsed time = %0.2f s\n",sum(T));
    end
%     fprintf("\nTotal processing time = %0.2f s\n",sum(T))
    fprintf("Total number of elements = %0.0f\n",numel(igstr))
    fprintf("DONE!\n");beep;
end
function [ogstr]    = CombineGDS_str(igstr,units)
% This function combine all elements in each layer. You might need to run
% the function more than once becase of a mistake in the GDS libaray!
    fprintf("\nRunning CombineGDS_str...\n");
    for idx = 1:length(igstr(:))
        L(idx) = layer(igstr(idx));
    end
    t=cputime;
    % initiate the output gds_strcut
    ogstr = gds_structure(get(igstr,'sname'));

    % start combining by performing or operation for each layer
    % indepenedantly 
   
    for L_idx = 1:max(L)
        clear LSt
        LSt = gds_structure(get(igstr,'sname'));
        % LSt is a gstr contains only one layer
        Lidx = find(L==L_idx);
        for idx = 1:length(Lidx)
            LSt(idx) = igstr(Lidx(idx));
        end

        % make sure that each element in LSt has only one boundary
        for i=1:length(LSt)
            A = LSt(i);
            if length(A)~=1
                error('ZAIN: reparse LSt so each element in LSt has only one boundary');
            end
        end,clear A


        while(~isempty(LSt(:)))
             fprintf("CombineGDS_str ... ")
             if length(LSt(:)) == 1
                ogstr(1+end) = LSt(1);
                LSt(1) = [];
             else
                % build the connection matrix
                C = logical(zeros(1,length(LSt(:))));
                for idx = 2:length(LSt(:))
                   [xyo, hf] = poly_boolmex(xy(LSt(1)), xy(LSt(idx)), 'or', units);
                   C(idx) = length(xyo(:))==1 | (length(xyo(:))==2 & any(hf));
                end
                if ~any(C)  % no connections, isolated
                    ogstr(1+end) = LSt(1);
                    LSt(1) = [];
                else        % connect the elements
                    C_idx = find(C);
                    for idx = 1:length(C_idx)
                        LSt(1) = Connect_gelm(LSt(1),LSt(C_idx(idx)),units);
                    end
                    LSt(C_idx)=[];
                end
             end
                fprintf("Precessing time = %0.2f s\n",cputime-t)         
        end
    end
    fprintf("DONE!\n");beep;
end
function [box_str]  = Creat_Mask(gst,NxN)
% creat NxN boxes for masking based on an input structure. The istr is only
% ussed to get the bbox of it
    box_max = bbox(gst);
    dx = box_max(3)-box_max(1);
    x1 = box_max(1);
    dy = box_max(4)-box_max(2);
    y1 = box_max(2);
    x = [0:NxN].*(1/NxN).*ones(NxN+1,NxN+1); x = x.*dx + x1;
    y = [0:NxN]'.*(1/NxN).*ones(NxN+1,NxN+1);y = y.*dy + y1;
    box_str = gds_structure('masks');
    for i_idx = 1:NxN
        for j_idx = 1:NxN
            box = [ x(i_idx,j_idx)      y(i_idx,j_idx);...
                    x(i_idx,j_idx+1)    y(i_idx,j_idx+1);...
                    x(i_idx+1,j_idx+1)  y(i_idx+1,j_idx+1);...
                    x(i_idx+1,j_idx)    y(i_idx+1,j_idx);...
                    x(i_idx,j_idx)      y(i_idx,j_idx)];
            box_str(1+end) = gds_element('boundary', 'xy', box);
        end
    end
end
function [ogstr]    = Split_gstr(igstr,NxN)
% Splits the istr gds_strcuture to NxN boxes so it can be exportable. The
% func will treat each layer seperately and the output will maintain the
% layer information

    fprintf("\nRunning Split_gstr...\n");
    t = cputime;
    [box_str] = Creat_Mask(igstr,NxN);
    Len = [];
    % initiate the output gds_strcut
    ogstr = gds_structure(get(igstr,'sname'));
    
    % get the all elements' layers in the structure
    for idx = 1:length(igstr(:))
        L(idx) = layer(igstr(idx));
    end
    % start splitting by performing and operation with the mask for each
    % layer indepenedantly
    for L_idx = 1:max(L)
        clear LSt
        LSt = gds_structure(get(igstr,'sname'));
        % LSt is a gstr contains only one layer
        Lidx = find(L==L_idx);
        for idx = 1:length(Lidx)
            LSt(idx) = igstr(Lidx(idx));
        end
        
        for b_idx = 1:length(box_str(:))
            fprintf("Split_gstr ...")
            for S_idx = 1:length(LSt(:))
               gelm = and(box_str(b_idx),LSt(S_idx));
               if isempty(xy(gelm))
                   continue;
               else
                   for idx = 1:length(gelm(:))
                       XY = gelm(idx);
                       XY = [XY(1:end,:);XY(1,:)];  % correct a mistake in (and)
                       XY = round(200*XY)./200;
                       ogstr(1+end) = gds_element('boundary', 'xy',XY,'layer',L_idx);
                       Len(1+end) = length(XY(:,1));
                   end
               end
            end
            fprintf("Total elapsed time = %0.1f s\n",cputime-t)
        end
    end
    fprintf("\nSplit_gstr:Maximum number of vertices = %0.0f\n",max(Len))
    fprintf("DONE!\n",max(Len));beep;
end
function [glib]     = ExportGDS(location,name,istr,uunit,dbunit)
% Export the GDS data to a file named 'name'.
% istr is a gds_structure with all the elements
istr = rename(istr, name);

if exist(strcat(strcat(location,name,'.gds')),'file')==2
    delete(strcat(location,name,'.gds'));
end

% create library
glib = gds_library(strcat(location,name,'.gds'), 'uunit',uunit, 'dbunit',dbunit, istr);
write_gds_library(glib, strcat(location,name,'.gds'));
S = load ('handel');
sound(S.y,S.Fs)
end
function [ogelm]    = minWidth_gelm(igelm,minWidth,minGrid,SmallestWireWidth,units)
L = layer(igelm);

XY = igelm(1);
[XY,c] = minWidth_corr(XY,minWidth,minGrid,SmallestWireWidth,units);
XY = flip(XY);
count = c;
[XY,count] = minWidth_corr(XY,minWidth,minGrid,SmallestWireWidth,units);
XY = flip(XY);
count = c + count;
ogelm = gds_element('boundary', 'xy',XY,'layer',L);

fprintf("Total number of corrections = %0.0f\n",count)
fprintf("DONE!\n")
end
function [ogstr]    = minWidth_gstr(igstr,minWidth,minGrid,SmallestWireWidth,units)
    fprintf("\nRunning minWidth_gstr...\n");
    % initiate the output gds_strcut
    ogstr = gds_structure(get(igstr,'sname'));
	for idx = 1:length(igstr(:))
		ogstr(idx) = minWidth_gelm(igstr(idx),minWidth,minGrid,SmallestWireWidth,units);
	end
	fprintf("minWidth_gstr...DONE!\n");beep;
end
function [ogelm1,ogelm2]    = Fix_hollowelm(igelm,units)
% this function will fix the slant intersections in any hollow element. the
% hollow elemnt will have two points common in its xy points. otherwise the
% function will return. normall the function will return two elements

    XY = cell2mat(xy(igelm));
    L = layer(igelm);
   % remove consecutive duplicates
    XY(diff(XY(:,1))==0 & diff(XY(:,2))==0,:) = []; 

    XY(end,:) = [];             % remove the last repeated point
    IDX = 1:length(XY(:,1));
    [C,IA,IC] = unique(XY,'rows');
    IDX(IA) = [];           % these are the locations of the repeated points. 
    cpt_idx = [];
    for idx = 1:length(IDX)
        cpt_idx(idx,:) = find(XY(:,1) == XY(IDX(idx),1) & XY(:,2) == XY(IDX(idx),2));
    end
    if isempty(cpt_idx)
        ogelm1 = [];ogelm2 = [];return
    end
    if length(cpt_idx(:,1)) >2
        error("ZAIN: you need manual intervention, more than two points")
    end

    cpt_idx = sortrows(cpt_idx,1);
    XY1 = cat(1,XY(1:cpt_idx(1,1),:),XY(cpt_idx(1,2)+1:end,:));
    XY1 = cat(1,XY1,XY1(1,:));
    XY2 = XY(cpt_idx(2,1):cpt_idx(2,2),:);

    XYb = bbox(igelm);
    %XYb(4) = (XYb(4)+XYb(2))/2;
    XYb(3) = (XYb(3)+XYb(1))/2;
    XY_box = [  XYb(1) XYb(2);...
                XYb(3) XYb(2);...
                XYb(3) XYb(4);...
                XYb(1) XYb(4);...
                XYb(1) XYb(2);...
                ];

    [XY_1, hf] = poly_boolmex({XY1}, {XY_box}, 'and', units);
    [XY_2, hf] = poly_boolmex({XY2}, {XY_box}, 'and', units);
    XY_1 = cell2mat(XY_1);XY_1 = cat(1,XY_1,XY_1(1,:));
    XY_2 = cell2mat(XY_2);XY_2 = cat(1,XY_2,XY_2(1,:));

    [XY_12, hf] = poly_boolmex({XY_1}, {XY_2}, 'diff', units);
    XY_12 = cell2mat(XY_12);XY_12 = cat(1,XY_12,XY_12(1,:));

    [XY_3, hf] = poly_boolmex({XY1}, {XY_box}, 'diff', units);
    [XY_4, hf] = poly_boolmex({XY2}, {XY_box}, 'diff', units);
    XY_3 = cell2mat(XY_3);XY_3 = cat(1,XY_3,XY_3(1,:));
    XY_4 = cell2mat(XY_4);XY_4 = cat(1,XY_4,XY_4(1,:));

    [XY_34, hf] = poly_boolmex({XY_3}, {XY_4}, 'diff', units);
    XY_34 = cell2mat(XY_34);XY_34 = cat(1,XY_34,XY_34(1,:));

    ogelm1 = gds_element('boundary', 'xy',{XY_12},'layer',L);
    ogelm2 = gds_element('boundary', 'xy',{XY_34},'layer',L);
end
function [ogstr]    = Fix_hollowstr(igstr,units)
    fprintf("Running Fix_hollowstr...");
    ogstr = gds_structure(get(igstr,'sname'));

    for idx = 1:length(igstr(:))
        [ogelm1,ogelm2]    = Fix_hollowelm(igstr(idx),units);
        if isempty(ogelm1)
            ogstr(1+end) = igstr(idx);
           continue; 
        else
            ogstr(1+end) = ogelm1;
            ogstr(1+end) = ogelm2;
        end    
    end
    fprintf("DONE!\n");    beep;
end
%-----------------------internal functions--------------
function [ogelm] = Connect_gelm(igelm1,igelm2,units)
% Connect two gds_elements that are connected together at one point while
% maintaing the shapes without any distrotion, 
    if layer(igelm1) ~= layer(igelm2)
        error("ZAIN: Layers of input elements don't match !")
        return;
    end
    L = layer(igelm1);                  % store the layer
    XY1 = {igelm1(1)};
    XY2 = {igelm2(1)};   % get the data in the gelms
    [XY1, hf] = poly_boolmex(XY1, XY2, 'or', units);
    if length(XY1(:))>2
        % get the biggest two elements, most likely the small things are
        % noise because of the descretization
        for idx=1:length(XY1(:))
            XY = XY1{idx};
            len(idx) = length(XY(:,1));
        end
        IDX = 1:length(XY1(:));
        [m,I1] = max(len(IDX));      
        IDX(I1) = [];
        [m,I2] = max(len(IDX));
        IDX(I2) = [];
        XY1(IDX) = [];  % remove all others except the largest two 
        hf(IDX)  = [];
    end
    if (length(XY1(:))==2 & any(hf)) %any(hf)
        XYinner = XY1{find(hf==1)};
        XYouter = XY1{find(hf==0)};
        XYinner = cat(1,XYinner,XYinner(1,:));
        XYouter = cat(1,XYouter,XYouter(1,:));

        % find the center of the proper element
        Xleft = min(XYouter(:,1));
        Xright = mean(XYinner(:,1));
        Y = mean(XYinner(:,2));
        e = 0.5/(100*units);
        XY_line = [ Xleft   Y-e;...
                    Xright  Y-e;...
                    Xright  Y+e;...
                    Xleft   Y+e;...
                    Xleft   Y-e];
        
        [XYouter, hf] = poly_boolmex({XYouter}, {XY_line}, 'diff', 1000*units);
        XYouter = cell2mat(XYouter);XYouter = cat(1,XYouter,XYouter(1,:));
        [XY1, hf] = poly_boolmex({XYouter}, {XYinner}, 'diff', 1000*units);
        XY1 = cell2mat(XY1);XY1 = {cat(1,XY1,XY1(1,:))};
    elseif (length(XY1(:))==1)
        XY1 = XY1{1};
        XY1 = cat(1,XY1,XY1(1,:));
        XY1 = {XY1};
    else
        XY1, hf
        error("ZAIN: The two elements are not connected !\n or the minGrid choise was too big creating holes in corners\n")
        return;
    end
    ogelm = gds_element('boundary', 'xy',XY1{1},'layer',L);
end
function [xo,yo] = Discritize_2P(X,Y,minGrid)
% This fucntion will generate many points in xo and yo so that they are all 
% on the grid specified given two points in X and Y. 
% X and Y must have two points only
    if length(X)~=2 | length(Y)~=2
        error("ZAIN: Discritize_2P function requires two points only")
        return
    end
    if X(2)~=X(1)
        a = (Y(2)-Y(1))/(X(2)-X(1));
        d = Y(1)-a*X(1);
        % I am not sure about the effect of limiting the number of elements
        % in the linear space function here by applying a power function
        x = linspace(X(1),X(2),(abs(X(1)-X(2))+1).^0.75);
        y = a*x+d;
        x = round(x/minGrid)*minGrid;
        y = round(y/minGrid)*minGrid;
        for idx=2:2:length(x)*2-1
            x = [x(1:idx-1) x(idx)   x(idx:end)];
            y = [y(1:idx-1) y(idx-1) y(idx:end)];
        end
        % elminate the repeated points
        xo = x;%(diff([0 x])~=0 | diff([0 y])~=0);
        yo = y;%(diff([0 x])~=0 | diff([0 y])~=0);
        %simplify horizontal and vertical lines
%         if ~any(diff(yo)) | ~any(diff(xo))   % y or x values doesnt change
%             xo = [xo(1) xo(end)]; 
%             yo = [yo(1) yo(end)];
%         end
%         if a==0
%             xo = [xo(1) xo(end)];
%             yo = [yo(1) yo(end)];
%         end
    else
% using this, the straight lines will have only two points and this is faster
% but to have a uniform data points, I use the code as below
        x = X(1:2);
        y = Y(1:2);
        xo = round(x/minGrid)*minGrid;
        yo = round(y/minGrid)*minGrid;
% %below
%         a = (X(2)-X(1))/(Y(2)-Y(1));
%         d = X(1)-a*Y(1);
%         % I am not sure about the effect of limiting the number of elements
%         % in the linear space function here by applying a power function
%         y = linspace(Y(1),Y(2),(abs(Y(1)-Y(2))+1).^0.75);
%         x = a*y+d;
%         x = round(x/minGrid)*minGrid;
%         y = round(y/minGrid)*minGrid;
%         for idx=2:2:length(y)*2-1
%             x = [x(1:idx-1) x(idx-1) x(idx:end)];
%             y = [y(1:idx-1) y(idx)   y(idx:end)];
%         end
%         xo = x;
%         yo = y;
% %end below 
    end
end
function [ogstr] = Many_Belm_to_single(gstr_name,igelm)
% convert from multiple bounderies to single boundey per element in a
% strcuture
% input is one element with many boundaries
% output is a gds_strcuture with many elements
           ogstr = gds_structure(gstr_name);
           L = get(igelm,'layer');
           for idx=1:length(igelm(:))
               ogstr(1+end) = gds_element('boundary', 'xy',igelm(idx),'layer',L);
           end
end
function [XY,count]= minWidth_scan(XY,window_size,minWidth,units,xy)
% this function scans an XY data for a minWidth DRC violation and correct
% it. it can scan either along x-axis or along y-axis depending on the
% option i
    if      xy=='x', i=2;
    elseif  xy=='y', i=1;
    else,   error("ZAIN: minWidth_corr(xy) is wrong")
    end
    count = 0;
    % look by sweeping along either x or y axis
    for idx = 1:length(XY(:,1))-window_size
        win = idx:idx+window_size-1;
        
        dXY = diff(XY(win,:),1,1);
        sdXY = sign(dXY);
        ywindow = sdXY(:,i);
        dy = abs(XY(idx,2)*ones(length(win),1) - XY(idx:idx+length(win)-1,2));
        dx = abs(XY(idx,1)*ones(length(win),1) - XY(idx:idx+length(win)-1,1));

        ya = ywindow;
        ya(find(ywindow == 0))=[];
        if any(find(diff(ya)))                  %it has a corner
            cor_idx = find(ywindow == -ya(1));
            cor_idx = cor_idx(1);             % the start of the corner
            if (dy(cor_idx) < minWidth/units) && (dx(cor_idx) < minWidth/units)
                count = count +1;                   % count the number of occurances
                cor_win = idx+1:idx+cor_idx-1;
%                IDX = cat(2,IDX,cor_win);% store the location of it
                XY(cor_win,i)=XY(idx,i);
            end
        end
    end

end
function [XY,count] = minWidth_corr(XY,minWidth,minGrid,SmallestWireWidth,units)
% This function will use minWidth_scan to do full sweep over a total
% element XY data. It will run scans to determine the best window size and
% ranges with overlap to minimize errors or unneeded diformations.
    count = [0 0 0];  % for forward and backward and total
    window_size = ceil(minWidth/minGrid);   % ceil to be in the safe side
    t = cputime;
    r = 0.9;             % control this if there is much deformation
    bigwin = round(r*SmallestWireWidth) + mod(round(r*SmallestWireWidth),2);
    for i=1:bigwin/2:length(XY(:,1))-bigwin
        fprintf("minWidth_corr: Processing time elapsed = %0.2f s\n",cputime-t);
        XY1 = XY(i:i+bigwin,:);
        XY2 = flip(XY(i:i+bigwin,:));

        count(1:2) = 0;
        % look by sweeping along x-axis
        [XY1,count(1)]= minWidth_scan(XY1,window_size,minWidth,units,'x');
        % look by sweeping along x-axis
        [XY2,count(2)]= minWidth_scan(XY2,window_size,minWidth,units,'x');

        if (count(1) <= count(2)) && (count(1) ~=0 )
             XY(i:i+bigwin,:) = XY1;count(3) = count(3)+count(1);
        else,XY(i:i+bigwin,:) = flip(XY2);count(3) = count(3)+count(2);
        end
        
        XY1 = XY(i:i+bigwin,:);
        XY2 = flip(XY(i:i+bigwin,:));

        count(1:2) = 0;
        % look by sweeping along y-axis
        [XY1,count(1)]= minWidth_scan(XY1,window_size,minWidth,units,'y');
        % look by sweeping along y-axis
        [XY2,count(2)]= minWidth_scan(XY2,window_size,minWidth,units,'y');

        if (count(1) <= count(2)) && (count(1) ~=0)
              XY(i:i+bigwin,:) = XY1;count(3) = count(3)+count(1);
        else, XY(i:i+bigwin,:) = flip(XY2);count(3) = count(3)+count(2);
        end
    end
    count = count(3);
    % remove consecutive duplicates
    XY(diff(XY(:,1))==0 & diff(XY(:,2))==0,:) = []; 
end
% -----------------OLD or BAD FUNCTIONS-------------------
function [glib] = Export_GDS_data(name,data,Layer,uunit,dbunit)
% Export the GDS data to a file named 'name'.
% data contains cells with the xy GDS boundary arrays.
% Layer contains an array with the layer of each data cell.
St = gds_structure(name);
for L_idx = 1:length(Layer)
    Ldata = data(find(Layer==L_idx));
    for S_idx = 1:length(Ldata)
        St(end+1) = gds_element('boundary', 'xy',cell2mat(Ldata{S_idx}), 'layer',L_idx);
    end
end
% create library
glib = gds_library(strcat(name,'.gds'), 'uunit',uunit, 'dbunit',dbunit, St);
write_gds_library(glib, strcat(name,'.gds'));
end
function [Cdata] = Stupid_Combine_GDS(data,E_Layer)
% Combine St in each layer. data contains cells with each structure and
% E_Layer contains the layer corrosponding to each structure in data cells.
% The problem is that if the structures are not connected, it will combine
% them which is not right. So proceed with caution

    for L_idx=1:max(E_Layer)
        XY=[];Ldata = {};I=[];
        Ldata = data(find(E_Layer==L_idx));
        for St_idx = 1:length(Ldata)              % Sort data
            temp = cell2mat(Ldata{St_idx});
            XY(St_idx,:) = temp(1,:);
        end
        [XY,I] = sort(XY(:,1),1);
        Sdata = Ldata(I);        % Sorted data
        XY=[];
        for St_idx = 1:length(Sdata)
            XY = cat(1,XY(1:end,:),cell2mat(Sdata{St_idx}));
        end
        Cdata{L_idx} = {XY};
    end
end
function [Cdata] = Combine_GDS(data,E_Layer)
% Combine data stored in data cells with the E_Layer as an array with the
% layer of each corrosponing cell. The output Cdata is a cell array with
% length of number of layers. 
    for L_idx = 1:max(E_Layer)
        Ldata = data(find(E_Layer==L_idx));
        for idx = 1:length(Ldata)
             St(idx) = gds_element('boundary', 'xy',cell2mat(Ldata{idx}));
        end
        CSt = St(1);
        for idx = 2:length(Ldata)
            CSt = poly_bool(CSt,St(idx),'or');
        end
        Cdata{L_idx} = {xy(CSt)};
    end
end
function [Con] = Get_GDSCon(igstr)
    fprintf("\nRunning Get_GDSCon...");
    % get all elements' layers in the structure
    for idx = 1:length(igstr(:))
        L(idx) = layer(igstr(idx));
    end
    % start by performing or operation for each layer
    % indepenedantly 
    for L_idx = 1:max(L)
       LSt = igstr(find(L==L_idx));
       
       % make sure that each element in LSt has only one boundary
       for i=1:length(LSt)
            A = LSt{i};
            if length(A)~=1
                error('ZAIN: reparse LSt so each element in LSt has only one boundary');
            end
        end
       
       % build the connection matrix for each layer in cell array 
       C = logical(zeros(length(LSt(:)),length(LSt(:))));
       for S_idx1 = 1:length(LSt(:))-1
           for S_idx2 = S_idx1+1:length(LSt(:))
               A = LSt{S_idx1};A = {A(1)};
               B = LSt{S_idx2};B = {B(1)};
               [xyo, hf] = poly_boolmex(A, B, 'or', 1000);
               C(S_idx1,S_idx2) = length(xyo(:))==1;
%               A = or(LSt{S_idx1},LSt{S_idx2});
%               C(S_idx1,S_idx2) = length(A(:))==1;
           end
       end
       Con{L_idx} = C;
    end 
%     fprintf("ZAIN:   Ignore all warnings, the function (or) was used to\n")
%     fprintf("find the intersections faster then the function (intersect)\n")
%     fprintf("in MATLAB! \n")
    fprintf("DONE!\n");
end
function [ogelm] = oldConnect_gelm(igelm1,igelm2,units)
% Connect two gds_elements that are connected together at one point while
% maintaing the shapes without any distrotion, 
% if you receive an error it might be because you didnt run this command on
% the descretize elements. This function only works with elements that are
% descretized.
    if layer(igelm1) ~= layer(igelm2)
        error("ZAIN: Layers of input elements don't match !")
        return;
    end
    L = layer(igelm1);                  % store the layer
    XY1 = {igelm1(1)};
    XY2 = {igelm2(1)};   % get the data in the gelms
    [XY1, hf] = poly_boolmex(XY1, XY2, 'or', units);
    
    if (length(XY1(:))==2 & any(hf)) %any(hf)
        XYinner = XY1{find(hf==1)};
        XYouter = XY1{find(hf==0)};
        A = sortrows(XYinner,2); % to get the mid point y-wise of inner
        [C,Ii,IB] = intersect(XYinner,A(round(length(A)/2),:),'rows');
                                        % Ii is the index of the midpoint in inner
        Io = find(XYouter(:,2) == C(1,2)); % The corrosponding index in outer
        %Io can have more than one point like on the right and left of the
        %inner, so it is wise to choose the one with the x closest to the x
        %of the inner 
        [m,mi] = min(abs(XYinner(Ii,1) - XYouter(Io,1)));Io = Io(mi);
        XYinner = circshift(XYinner,-Ii,1);   % inner 1 is that point
        %%XYinner = flip(XYinner,1);
        XYouter = circshift(XYouter,-Io(1),1);  % outer end is that point
        % to make sure we return to the same point for a good horizontal line
        XYouter = cat(1,XYouter(end,:),XYouter);
        XY1 = cat(1,XYinner,XYouter);
        XY1 = {cat(1,XY1,XY1(1,:))};
    elseif (length(XY1(:))==1)
        XY1 = XY1{1};
        XY1 = cat(1,XY1,XY1(1,:));
        XY1 = {XY1};
    else
        XY1, hf
        error("ZAIN: The two elements are not connected !\n or the minGrid choise was too big creating holes in corners\n")
        return;
    end
    ogelm = gds_element('boundary', 'xy',XY1{1},'layer',L);
end


%---------------------OLD CODES--------------------------
%%
% % this code works well with minGrid=200 and minWidth=600 
% clc
% close all
% minWidth = 600; % in dbunits, so at least we need minWidth + minGrid to pass
% window_size = ceil(minWidth/minGrid);
% 
% igelm = CSt(1);
% XY = cell2mat(xy(igelm));
% origXY = XY;
% 
% for i = 1:10
%     count = 0;
%     IDX = [];   % to follow the changes
%     
%     dXY = cat(1,[0 0],diff(XY,1,1));
%     sdXY = sign(dXY);
%     % look by sweeping along x-axis
%     for idx = 1:length(XY(:,1))-window_size
%         win = idx:idx+window_size-1;
% 
%         ywindow = sdXY(win,2);
%         dx = abs(dXY(win(2),1) - dXY(win(1),1));
% 
%         ya = ywindow;
%         ya(find(ywindow == 0))=[];
%         if any(find(diff(ya))) & dx<= minWidth/units          % it has a corner
%             count = count +1;
%             IDX = cat(2,IDX,win);
%             XY(win,2) = XY(win(end),2).*ones(length(win),1);
%         end
%     end
%     
%     dXY = cat(1,[0 0],diff(XY,1,1));
%     sdXY = sign(dXY);
%     % look by sweeping along y-axis
%     for idx = 1:length(XY(:,1))-window_size
%         win = idx:idx+window_size-1;
%         
%         xwindow = sdXY(win,1);
%         dy = abs(dXY(win(2),2) - dXY(win(1),2));
% 
%         xa = xwindow;
%         xa(find(xwindow == 0))=[];
%         if any(find(diff(xa))) & dy<= minWidth/units          % it has a corner
%             count = count +1;
%             IDX = cat(2,IDX,win);
%             XY(win,1) = XY(win(end),1).*ones(length(win),1);
%         end
%     end
% 
%     fprintf("Total number of corrections = %0.0f\n",count)
%     figure
%     plot(origXY(IDX,1),origXY(IDX,2),'bx'),hold on
%     plot(XY(:,1),XY(:,2),'k-'),hold on
%     plotGDS_elm(igelm,'r-.')
%     if count == 0
%         fprintf("No more corrections...DONE!\n",count)
%         break;
%     end
% end
