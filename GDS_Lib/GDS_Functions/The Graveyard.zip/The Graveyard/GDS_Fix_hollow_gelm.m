function [ogelm1,ogelm2]    = GDS_Fix_hollow_gelm(igelm,units)
% this function will fix the slant intersections in any hollow element. the
% hollow elemnt will have two points common in its xy points. otherwise the
% function will return. normall the function will return two elements

    XY = cell2mat(xy(igelm));
    L = layer(igelm);
   % remove consecutive duplicates
    XY(diff(XY(:,1))==0 & diff(XY(:,2))==0,:) = []; 

    XY(end,:) = [];             % remove the last repeated point
    IDX = 1:length(XY(:,1));
    [C,IA,IC] = unique(XY,'rows');
    IDX(IA) = [];           % these are the locations of the repeated points. 
    cpt_idx = [];
    for idx = 1:length(IDX)
        cpt_idx(idx,:) = find(XY(:,1) == XY(IDX(idx),1) & XY(:,2) == XY(IDX(idx),2));
    end
    if isempty(cpt_idx)
        ogelm1 = [];ogelm2 = [];return
    end
    if length(cpt_idx(:,1)) >2
        error("ZAIN: you need manual intervention, more than two points")
    end

    cpt_idx = sortrows(cpt_idx,1);
    XY1 = cat(1,XY(1:cpt_idx(1,1),:),XY(cpt_idx(1,2)+1:end,:));
    XY1 = cat(1,XY1,XY1(1,:));
    XY2 = XY(cpt_idx(2,1):cpt_idx(2,2),:);

    XYb = bbox(igelm);
    %XYb(4) = (XYb(4)+XYb(2))/2;
    XYb(3) = (XYb(3)+XYb(1))/2;
    XY_box = [  XYb(1) XYb(2);...
                XYb(3) XYb(2);...
                XYb(3) XYb(4);...
                XYb(1) XYb(4);...
                XYb(1) XYb(2);...
                ];

    [XY_1, hf] = poly_boolmex({XY1}, {XY_box}, 'and', units);
    [XY_2, hf] = poly_boolmex({XY2}, {XY_box}, 'and', units);
    XY_1 = cell2mat(XY_1);XY_1 = cat(1,XY_1,XY_1(1,:));
    XY_2 = cell2mat(XY_2);XY_2 = cat(1,XY_2,XY_2(1,:));

    [XY_12, hf] = poly_boolmex({XY_1}, {XY_2}, 'diff', units);
    XY_12 = cell2mat(XY_12);XY_12 = cat(1,XY_12,XY_12(1,:));

    [XY_3, hf] = poly_boolmex({XY1}, {XY_box}, 'diff', units);
    [XY_4, hf] = poly_boolmex({XY2}, {XY_box}, 'diff', units);
    XY_3 = cell2mat(XY_3);XY_3 = cat(1,XY_3,XY_3(1,:));
    XY_4 = cell2mat(XY_4);XY_4 = cat(1,XY_4,XY_4(1,:));

    [XY_34, hf] = poly_boolmex({XY_3}, {XY_4}, 'diff', units);
    XY_34 = cell2mat(XY_34);XY_34 = cat(1,XY_34,XY_34(1,:));

    ogelm1 = gds_element('boundary', 'xy',{XY_12},'layer',L);
    ogelm2 = gds_element('boundary', 'xy',{XY_34},'layer',L);
end

