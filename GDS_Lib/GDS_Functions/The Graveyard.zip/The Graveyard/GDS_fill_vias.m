function [ogstr] = GDS_fill_vias(igstr,Mosaic,layer,seperation,units)
% this function will fill a igstr with boxes for via fillings, the details
% of the vies dimentions are Mosaic (b)box, (d)distance and (e)edges. It is better
% to split the gstr before coming here for large structures.
% The output gstr is a cell array of gds strutures
% - The function will fill every element in the input structure regardless
% of its layer. 

fprintf("\nRunning GDS_fill_vias...\n")

    t=cputime;          

     for idx = 1:length(igstr(:))
        igelm = igstr(idx);
        igelm = GDS_shrink_gelm(igelm,seperation,units);
        
        [RC Center] = GDS_Mosaic_calc(igelm,Mosaic);
% Discretize 
minGrid = 10/1000;          % it is better to do this as an input later on
Center = round(Center./minGrid).*minGrid;
        gelm = GDS_Create_box(Mosaic.b,Center,layer);
        gstr = GDS_Mosaic_gelm(gelm,Mosaic.e,Mosaic.d,RC);

        ogstr(idx) = {GDS_AND(igelm,gstr,layer,units)};
     end
     fprintf("Time elapsed = %0.2f S\nDONE!\n",cputime-t)
end
