function GDS_plot_XY(data,str)
    hold on
    for idx = 1:length(data)
        XY = cell2mat(data(idx));
        plot(XY(:,1),XY(:,2),str)
    end
    hold off
    axis equal
end


