function [ogstr]    = GDS_Fix_hollow_gstr(igstr,units)
    fprintf("Running Fix_hollowstr...");
    ogstr = gds_structure(get(igstr,'sname'));

    for idx = 1:length(igstr(:))
        [ogelm1,ogelm2]    = GDS_Fix_hollow_gelm(igstr(idx),units);
        if isempty(ogelm1)
            ogstr(1+end) = igstr(idx);
           continue; 
        else
            ogstr(1+end) = ogelm1;
            ogstr(1+end) = ogelm2;
        end    
    end
    fprintf("DONE!\n");    beep;
end

